module.exports = {
  plugins: [require('postcss-rtl')],
}
