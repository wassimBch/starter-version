# Vue 3 Notes

## Things to take care of:

- Scoped styles
